
function getParam(name){
  const url = new URL(window.location.href);
  return url.searchParams.get(name);
}
function money(n){ return Number(n).toFixed(0); }

function updateFromParams(){
  const name = getParam('product') || 'Sanatani Chai Gold';
  const price = Number(getParam('price') || 350);
  document.getElementById('pName').textContent = name;
  document.getElementById('pPrice').textContent = price;
  document.getElementById('sName').textContent = name;
  document.getElementById('sPrice').textContent = price;
  updateTotal();
}
function updateTotal(){
  const price = Number(document.getElementById('pPrice').textContent);
  const qty = Math.max(1, Number(document.getElementById('qty').value || 1));
  document.getElementById('sQty').textContent = qty;
  const sub = price * qty;
  document.getElementById('sSub').textContent = money(sub);
  const ship = sub >= 999 ? 0 : 59;
  document.getElementById('sShip').textContent = money(ship);
  document.getElementById('sTotal').textContent = money(sub + ship);
}
function selectPayment(method){
  document.getElementById('payMethod').value = method;
  alert('Selected: ' + method + '\n(This is a demo — connect your real gateway later.)');
}
function handleCheckoutSubmit(){
  const data = {
    name: document.getElementById('name').value,
    email: document.getElementById('email').value,
    phone: document.getElementById('phone').value,
    address: document.getElementById('address').value,
    product: document.getElementById('pName').textContent,
    price: Number(document.getElementById('pPrice').textContent),
    qty: Number(document.getElementById('qty').value),
    payment: document.getElementById('payMethod').value,
    total: Number(document.getElementById('sTotal').textContent)
  };
  // In production: send to your backend, then redirect to Paytm/Stripe/Razorpay
  console.log('Order:', data);
  alert('Order created!\nTotal: ₹' + data.total + '\nPayment: ' + data.payment + '\n\n(Integrate Paytm/UPI/Card gateway to accept real payments.)');
}
document.addEventListener('DOMContentLoaded', updateFromParams);
